package com.northconcepts.datapipeline.examples.cookbook;

import com.northconcepts.datapipeline.core.DataReader;
import com.northconcepts.datapipeline.core.DataWriter;
import com.northconcepts.datapipeline.core.PipedReader;
import com.northconcepts.datapipeline.core.PipedWriter;
import com.northconcepts.datapipeline.core.Record;
import com.northconcepts.datapipeline.core.StreamWriter;
import com.northconcepts.datapipeline.job.JobTemplate;

public class PipeAWriterToAReader {
    
    public static void main(String[] args) {
        RecordProducer producer = new RecordProducer();
        producer.start();
        
        DataReader reader = producer.getReader();
        DataWriter writer = new StreamWriter(System.out);        
        
        JobTemplate.DEFAULT.transfer(reader, writer);
    }


    public static class RecordProducer extends Thread {
        
        private final PipedReader reader = new PipedReader();
        private final PipedWriter writer = new PipedWriter(reader);

        public RecordProducer() {
        }
        
        public PipedReader getReader() {
            return reader;
        }
        
        @Override
        public void run() {
            writer.open();
            try {
                for (int i = 0; i < 20; i++) {
                    Record r = new Record();
                    r.setField("key", "key-" + i);
                    r.setField("value", "value-" + i);
                    writer.write(r);
                }
            } finally {
                writer.close();
            }
        }
        
    }
    
}
